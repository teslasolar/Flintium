"""flintium - shared helpers for the Flintium Perspective project."""
